import os

# BASE_DIR = os.path.abspath(os.path.dirname(__file__))
# UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
# MAX_CONTENT_LENGTH = 250 * 1024 * 1024
# ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'}
# AUTO_CLEAN_SECONDS = 600

# os.makedirs(UPLOAD_FOLDER, exist_ok=True)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_IMG = {"png", "jpg", "jpeg", "gif", "webp"}
ALLOWED_PDF = {"pdf"}

BLOG_FILE = "blog.json"

ADMIN_USERNAME = "ReformPix"
ADMIN_PASSWORD = "ReformPix@1877"

SECRET_KEY = os.environ.get("SECRET_KEY", "reformpix-secret")
CACHE_TIMEOUT = 300