def make_cache_key(request, prefix=""):
  parts = [prefix]
  if request.form:
    for k,v in sorted(request.form.items()):
      parts.append(f"{k}:{v}")
  if request.files:
    for k,v in sorted(request.files.items()):
      parts.append(f"{k}:{v.filename}")
  return "-".join(parts)