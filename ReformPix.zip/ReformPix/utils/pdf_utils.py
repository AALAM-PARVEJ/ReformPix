
import io
from PIL import Image
import PyPDF2
from PyPDF2 import PdfWriter, PdfReader

def images_to_pdf(image_files):
    try:
        images = []
        
        for file in image_files:
            if file.filename:
                img = Image.open(file)
                # Convert to RGB if necessary
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                images.append(img)
        
        if not images:
            raise Exception("No valid images provided")
        
        buf = io.BytesIO()
        
        # Save the first image and append the rest
        if len(images) == 1:
            images[0].save(buf, format='PDF')
        else:
            images[0].save(buf, format='PDF', save_all=True, append_images=images[1:])
        
        buf.seek(0)
        return buf
    except Exception as e:
        raise Exception(f"Error creating PDF: {str(e)}")

def reduce_pdf(file, quality):
    try:
        reader = PdfReader(file)
        writer = PdfWriter()
        
        for page in reader.pages:
            # Compress the page
            page.compress_content_streams()
            writer.add_page(page)
        
        buf = io.BytesIO()
        writer.write(buf)
        buf.seek(0)
        return buf
    except Exception as e:
        raise Exception(f"Error reducing PDF: {str(e)}")
