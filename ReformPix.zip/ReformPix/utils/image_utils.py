
import io
import os
from PIL import Image, ImageEnhance, ImageFilter
import cairosvg

def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

def resize_image(file, width, width_unit, height, height_unit, keep_aspect=False):
    try:
        img = Image.open(file)
        # Convert units to pixels
        def convert_to_pixels(value, unit, original_size):
            if not value:
                return None
            value = float(value)
            if unit == 'px':
                return int(value)
            elif unit == '%':
                return int(original_size * value / 100)
            elif unit == 'cm':
                return int(value * 37.795275591)  # 1cm = ~37.8px at 96dpi
            elif unit == 'in':
                return int(value * 96)  # 1in = 96px at 96dpi
            return int(value)
        
        original_width, original_height = img.size
        
        new_width = convert_to_pixels(width, width_unit, original_width)
        new_height = convert_to_pixels(height, height_unit, original_height)
        
        if keep_aspect:
            if new_width and not new_height:
                new_height = int(original_height * new_width / original_width)
            elif new_height and not new_width:
                new_width = int(original_width * new_height / original_height)
            elif new_width and new_height:
                # Maintain aspect ratio with the smaller dimension
                width_ratio = new_width / original_width
                height_ratio = new_height / original_height
                ratio = min(width_ratio, height_ratio)
                new_width = int(original_width * ratio)
                new_height = int(original_height * ratio)
        
        if not new_width:
            new_width = original_width
        if not new_height:
            new_height = original_height
            
        resized_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        buf = io.BytesIO()
        resized_img.save(buf, format='PNG')
        buf.seek(0)
        return buf
    except Exception as e:
        raise Exception(f"Error resizing image: {str(e)}")

def compress_image(file, target_size, unit):
    try:
        img = Image.open(file)
        
        # Convert target size to bytes
        if unit == 'MB':
            target_bytes = target_size * 1024 * 1024
        else:  # KB
            target_bytes = target_size * 1024
        
        # Convert to RGB if necessary
        if img.mode in ('RGBA', 'P'):
            img = img.convert('RGB')
        
        quality = 95
        buf = io.BytesIO()
        
        while quality > 10:
            buf.seek(0)
            buf.truncate()
            img.save(buf, format='JPEG', quality=quality, optimize=True)
            
            if buf.tell() <= target_bytes:
                break
            quality -= 5
        
        buf.seek(0)
        return buf
    except Exception as e:
        raise Exception(f"Error compressing image: {str(e)}")

def convert_image(file, target_format):
    try:
        buf = io.BytesIO()
        
        if target_format.upper() == 'SVG':
            # For SVG, we'll create a simple SVG wrapper (basic conversion)
            img = Image.open(file)
            img_io = io.BytesIO()
            img.save(img_io, format='PNG')
            img_io.seek(0)
            
            import base64
            img_data = base64.b64encode(img_io.getvalue()).decode()
            
            svg_content = f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
     width="{img.width}" height="{img.height}">
  <image width="{img.width}" height="{img.height}" 
         xlink:href="data:image/png;base64,{img_data}"/>
</svg>'''
            buf.write(svg_content.encode())
        else:
            img = Image.open(file)
            
            # Handle different formats
            if target_format.upper() in ['JPG', 'JPEG']:
                if img.mode in ('RGBA', 'P'):
                    img = img.convert('RGB')
                img.save(buf, format='JPEG', quality=95, optimize=True)
            elif target_format.upper() == 'PNG':
                img.save(buf, format='PNG', optimize=True)
            elif target_format.upper() == 'WEBP':
                img.save(buf, format='WEBP', quality=95, optimize=True)
            elif target_format.upper() == 'GIF':
                img.save(buf, format='GIF', optimize=True)
            else:
                img.save(buf, format=target_format.upper())
        
        buf.seek(0)
        return buf
    except Exception as e:
        raise Exception(f"Error converting image: {str(e)}")

def enhance_image(file, brightness, contrast, sharpness):
    try:
        img = Image.open(file)
        
        # Apply enhancements
        if brightness != 1.0:
            enhancer = ImageEnhance.Brightness(img)
            img = enhancer.enhance(brightness)
        
        if contrast != 1.0:
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(contrast)
        
        if sharpness != 1.0:
            enhancer = ImageEnhance.Sharpness(img)
            img = enhancer.enhance(sharpness)
        
        buf = io.BytesIO()
        img.save(buf, format='PNG', optimize=True)
        buf.seek(0)
        return buf
    except Exception as e:
        raise Exception(f"Error enhancing image: {str(e)}")
