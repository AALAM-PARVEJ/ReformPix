
// Simple JavaScript for the image tools site
document.addEventListener('DOMContentLoaded', function() {
    // Handle mobile menu toggle if it exists
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            const navRight = document.querySelector('.nav-right');
            if (navRight) {
                navRight.classList.toggle('mobile-open');
            }
        });
    }

    // Handle drag and drop for upload forms
    const dropZones = document.querySelectorAll('#dropZone, [id$="-drop"]');
    dropZones.forEach(function(dropZone) {
        if (dropZone) {
            const fileInput = dropZone.querySelector('input[type="file"]') || 
                            document.querySelector('#imageInput, #resize-input');
            
            if (fileInput) {
                // Click to upload
                dropZone.addEventListener('click', function() {
                    fileInput.click();
                });

                // Drag and drop events
                dropZone.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    dropZone.classList.add('dragover', 'drag-over');
                });

                dropZone.addEventListener('dragleave', function(e) {
                    e.preventDefault();
                    dropZone.classList.remove('dragover', 'drag-over');
                });

                dropZone.addEventListener('drop', function(e) {
                    e.preventDefault();
                    dropZone.classList.remove('dragover', 'drag-over');
                    
                    const files = e.dataTransfer.files;
                    if (files.length > 0) {
                        fileInput.files = files;
                        handleFileSelect(files[0]);
                    }
                });

                // File input change event
                fileInput.addEventListener('change', function(e) {
                    if (e.target.files.length > 0) {
                        handleFileSelect(e.target.files[0]);
                    }
                });
            }
        }
    });

    // Handle file selection and preview
    function handleFileSelect(file) {
        console.log('Files selected:', file.name);
        
        // Show preview if preview element exists
        const preview = document.getElementById('preview');
        const previewImg = document.getElementById('previewImg') || 
                          document.getElementById('resize-preview');
        
        if (preview && previewImg && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewImg.src = e.target.result;
                previewImg.classList.remove('hidden');
                if (preview.classList) {
                    preview.classList.remove('hidden');
                }
            };
            reader.readAsDataURL(file);
        }
    }

    // Handle form submissions with progress
    const forms = document.querySelectorAll('form[enctype="multipart/form-data"]');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            const progressBox = document.getElementById('progressBox') || 
                              document.getElementById('progress-container');
            const progressBar = document.getElementById('progressBar');
            
            if (progressBox && progressBar) {
                progressBox.classList.remove('hidden');
                
                // Simulate progress (since we can't track actual upload progress easily)
                let progress = 0;
                const interval = setInterval(function() {
                    progress += Math.random() * 30;
                    if (progress > 90) progress = 90;
                    progressBar.style.width = progress + '%';
                }, 200);
                
                // Clear interval after form submission
                setTimeout(function() {
                    clearInterval(interval);
                    progressBar.style.width = '100%';
                }, 2000);
            }
        });
    });
});
