// static/js/upload.js
document.addEventListener("DOMContentLoaded", () => {
  // Generic setup for any page with a .drop-area container
  document.querySelectorAll(".drop-area").forEach(area => {
    const fileInput = area.querySelector("input[type=file]");
    const previewImg = area.querySelector(".preview-img");
    const previewContainer = area.querySelector(".preview-container");
    const progressBox = area.querySelector(".progress-box");
    const progressBar = area.querySelector(".progress-bar");

    if (!fileInput) return;

    // Only open file picker when user clicks the drop area but NOT when clicking
    // an interactive control inside it (buttons/selects/links/inputs).
    area.addEventListener("click", (e) => {
      // If clicking an interactive element, do not open the picker.
      const tag = e.target.tagName ? e.target.tagName.toLowerCase() : "";
      if (tag === "input" || tag === "button" || tag === "select" || tag === "a" || tag === "label") {
        return;
      }
      // Also if the clicked element (or its ancestor) has data-no-file attribute, skip.
      if (e.target.closest("[data-no-file]")) return;

      // If the user clicked inside the drop area but not on an interactive element, open file picker.
      fileInput.click();
    });

    // Drag events
    area.addEventListener("dragover", e => {
      e.preventDefault();
      area.classList.add("bg-blue-50", "border-blue-300");
    });
    area.addEventListener("dragleave", () => {
      area.classList.remove("bg-blue-50", "border-blue-300");
    });

    area.addEventListener("drop", e => {
      e.preventDefault();
      area.classList.remove("bg-blue-50", "border-blue-300");
      if (e.dataTransfer.files.length) {
        fileInput.files = e.dataTransfer.files;
        showPreview(fileInput.files[0], previewImg, previewContainer);
      }
    });

    // When file selected
    fileInput.addEventListener("change", () => {
      if (fileInput.files.length) {
        showPreview(fileInput.files[0], previewImg, previewContainer);
      }
    });

    // Form submit handling with XHR progress (if form is inside same container)
    const form = area.closest("form");
    if (form) {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const submitBtn = form.querySelector("button[type=submit]");
        submitBtn.disabled = true;
        const xhr = new XMLHttpRequest();
        xhr.open("POST", form.action, true);
        xhr.responseType = "blob";

        xhr.upload.onprogress = (ev) => {
          if (ev.lengthComputable && progressBar) {
            progressBox && progressBox.classList.remove("hidden");
            const pct = Math.round((ev.loaded / ev.total) * 100);
            progressBar.style.width = pct + "%";
          }
        };

        xhr.onload = () => {
          submitBtn.disabled = false;
          if (xhr.status === 200) {
            // Get filename from header if present
            let filename = "output";
            const disp = xhr.getResponseHeader("Content-Disposition");
            if (disp && disp.indexOf("filename=") !== -1) {
              filename = disp.split("filename=")[1].replace(/"/g, "");
            } else {
              // fallback by content-type
              const ct = xhr.getResponseHeader("Content-Type") || "";
              if (ct.includes("pdf")) filename = "output.pdf";
              else if (ct.includes("svg")) filename = "output.svg";
              else filename = "output.png";
            }

            const blob = xhr.response;
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            a.remove();

            // success feedback
            alert("✅ Download started — check your downloads folder.");
            progressBox && (progressBar.style.width = "0%");
          } else {
            alert("❌ Something went wrong. Please try again.");
          }
        };

        const fm = new FormData(form);
        xhr.send(fm);
      });
    }
  });

  function showPreview(file, imgElem, container) {
    if (!file || !imgElem) return;
    const reader = new FileReader();
    reader.onload = function (e) {
      imgElem.src = e.target.result;
      container && container.classList.remove("hidden");
    };
    reader.readAsDataURL(file);
  }
});