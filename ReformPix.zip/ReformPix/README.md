# ImageToolsPro - Flask Image Tool

Local development:
1. Create virtualenv: `python -m venv venv && source venv/bin/activate`
2. Install: `pip install -r requirements.txt`
3. Run: `python backend/app.py`
4. Open http://127.0.0.1:3000

Notes:
- Temporary uploads stored in `backend/uploads` and auto-cleaned (files older than 10 minutes).
- Add a proper secret key and HTTPS when deploying.
- Add privacy & terms pages before applying for AdSense.