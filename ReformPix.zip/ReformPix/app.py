import os, io, json, logging
from datetime import datetime
from flask import (Flask, render_template, request, redirect, url_for,
                   send_file, abort, flash, session)
from werkzeug.utils import secure_filename
from flask_caching import Cache

import config
from utils.image_utils import (resize_image_bytes, compress_image_bytes,
                               convert_image_bytes, enhance_image_bytes,
                               images_to_pdf_bytes)
from utils.pdf_utils import compress_pdf_bytes

app = Flask(__name__)
app.secret_key = config.SECRET_KEY

# caching
cache = Cache(app, config={"CACHE_TYPE": "SimpleCache", "CACHE_DEFAULT_TIMEOUT": config.CACHE_TIMEOUT})

# logging
if not os.path.exists("logs"):
    os.makedirs("logs")
logging.basicConfig(filename="logs/app.log", level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")

# helpers
def save_uploaded_file(f):
    filename = secure_filename(f.filename)
    path = os.path.join(config.UPLOAD_FOLDER, filename)
    f.save(path)
    return path

def load_blogs():
    if not os.path.exists(config.BLOG_FILE):
        return []
    with open(config.BLOG_FILE, "r", encoding="utf-8") as fh:
        return json.load(fh)

def save_blogs(posts):
    with open(config.BLOG_FILE, "w", encoding="utf-8") as fh:
        json.dump(posts, fh, indent=2, ensure_ascii=False)
    cache.delete("blogs")

@app.context_processor
def inject_common():
    return {"brand": "ReformPix", "year": datetime.now().year, "admin_username": config.ADMIN_USERNAME}

# ---------- Pages ----------
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/resize", methods=["GET", "POST"])
def resize():
    if request.method == "POST":
        file = request.files.get("file")
        if not file:
            flash("Please upload a file.")
            return redirect(request.url)
        unit = request.form.get("unit", "px")
        width = request.form.get("width", "")
        height = request.form.get("height", "")
        keep_aspect = bool(request.form.get("keep_aspect"))
        # process as bytes and return
        data = resize_image_bytes(file.stream.read(), width, height, unit, keep_aspect)
        logging.info(f"Resized: {file.filename}")
        return send_file(io.BytesIO(data), download_name="resized.png", as_attachment=True, mimetype="image/png")
    return render_template("resize.html")

@app.route("/compress", methods=["GET", "POST"])
def compress():
    if request.method == "POST":
        file = request.files.get("file")
        quality = int(request.form.get("quality", 80))
        data = compress_image_bytes(file.stream.read(), quality)
        logging.info(f"Compressed: {file.filename} quality={quality}")
        return send_file(io.BytesIO(data), download_name="compressed.jpg", as_attachment=True, mimetype="image/jpeg")
    return render_template("compress.html")

@app.route("/convert", methods=["GET", "POST"])
def convert():
    if request.method == "POST":
        file = request.files.get("file")
        fmt = request.form.get("format", "png")
        data, mime, ext = convert_image_bytes(file.stream.read(), fmt)
        logging.info(f"Converted {file.filename} -> {fmt}")
        return send_file(io.BytesIO(data), download_name=f"converted.{ext}", as_attachment=True, mimetype=mime)
    return render_template("convert.html")

@app.route("/enhance", methods=["GET", "POST"])
def enhance():
    if request.method == "POST":
        file = request.files.get("file")
        brightness = float(request.form.get("brightness", 1.0))
        contrast = float(request.form.get("contrast", 1.0))
        sharpness = float(request.form.get("sharpness", 1.0))
        data = enhance_image_bytes(file.stream.read(), brightness, contrast, sharpness)
        logging.info(f"Enhanced: {file.filename}")
        return send_file(io.BytesIO(data), download_name="enhanced.png", as_attachment=True, mimetype="image/png")
    return render_template("enhance.html")

@app.route("/img-to-pdf", methods=["GET", "POST"])
def img_to_pdf():
    if request.method == "POST":
        files = request.files.getlist("files")
        img_bytes = [f.stream.read() for f in files if f]
        data = images_to_pdf_bytes(img_bytes)
        logging.info(f"Images -> PDF: {len(img_bytes)} files")
        return send_file(io.BytesIO(data), download_name="images.pdf", as_attachment=True, mimetype="application/pdf")
    return render_template("img_to_pdf.html")

@app.route("/pdf-reduce", methods=["GET", "POST"])
def pdf_reduce():
    if request.method == "POST":
        file = request.files.get("file")
        level = request.form.get("level", "medium")
        data = compress_pdf_bytes(file.stream.read(), level)
        logging.info(f"PDF compressed: {file.filename} level={level}")
        return send_file(io.BytesIO(data), download_name="reduced.pdf", as_attachment=True, mimetype="application/pdf")
    return render_template("pdf_compress.html")

# ---------- Blog (public) ----------
@app.route("/blog")
def blog():
    posts = cache.get("blogs")
    if posts is None:
        posts = load_blogs()
        cache.set("blogs", posts)
    return render_template("blog.html", posts=posts)

@app.route("/blog/<int:post_id>")
def blog_post(post_id):
    posts = load_blogs()
    post = next((p for p in posts if p["id"]==post_id), None)
    if not post:
        abort(404)
    return render_template("blog_post.html", post=post)

# ---------- Admin ----------
def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*a, **k):
        if not session.get("admin"):
            return redirect(url_for("login"))
        return fn(*a, **k)
    return wrapper

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        if request.form.get("username")==config.ADMIN_USERNAME and request.form.get("password")==config.ADMIN_PASSWORD:
            session["admin"]=True
            return redirect(url_for("dashboard"))
        flash("Invalid credentials", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    posts = load_blogs()
    last = posts[-1] if posts else None
    return render_template("dashboard.html", total=len(posts), last=last)

@app.route("/blog-admin", methods=["GET","POST"])
@login_required
def blog_admin():
    posts = load_blogs()
    edit_id = request.args.get("edit")
    edit_post = None
    if edit_id:
        edit_post = next((p for p in posts if p["id"]==int(edit_id)), None)

    if request.method=="POST":
        title = request.form["title"]
        content = request.form["content"]
        if request.form.get("post_id"):  # edit
            pid = int(request.form["post_id"])
            post = next((p for p in posts if p["id"]==pid), None)
            if post:
                post["title"] = title
                post["content"] = content
                post["date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        else:
            new = {"id": (posts[-1]["id"]+1) if posts else 1,
                   "title": title,
                   "content": content,
                   "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            posts.append(new)
        save_blogs(posts)
        return redirect(url_for("blog_admin"))
    return render_template("blog_admin.html", posts=posts, edit_post=edit_post)

@app.route("/blog-delete/<int:post_id>", methods=["POST"])
@login_required
def blog_delete(post_id):
    posts = load_blogs()
    posts = [p for p in posts if p["id"]!=post_id]
    save_blogs(posts)
    return redirect(url_for("blog_admin"))

# ---------- Static pages ----------
@app.route("/privacy")
def privacy():
    return render_template("privacy.html")

@app.route("/terms")
def terms():
    return render_template("terms.html")

if __name__=="__main__":
    app.run(debug=True, host="0.0.0.0")